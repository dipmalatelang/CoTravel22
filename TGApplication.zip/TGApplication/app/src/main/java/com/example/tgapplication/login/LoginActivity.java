package com.example.tgapplication.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.example.tgapplication.R;
import com.example.tgapplication.trips.TripsActivity;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LoginActivity extends AppCompatActivity {
    @BindView(R.id.regi_form)
    LinearLayout regiForm;
    @BindView(R.id.regi_more_form)
    LinearLayout regiMoreForm;
    private LoginButton loginButton;
    private static final String EMAIL = "email";
    private CallbackManager callbackManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        callbackManager = CallbackManager.Factory.create();

        loginButton = (LoginButton) findViewById(R.id.login_button);
        loginButton.setReadPermissions(Arrays.asList(EMAIL));
        // If you are using in a fragment, call loginButton.setFragment(this);    

        // Callback registration
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // App code

            }

            @Override
            public void onCancel() {
                // App code
            }

            @Override
            public void onError(FacebookException exception) {
                // App code

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Intent secondActivityIntent = new Intent(this, TripsActivity.class);
            startActivity(secondActivityIntent);
        }
    }

    @OnClick({R.id.btn_regi1, R.id.btn_regi})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_regi1:
                regiForm.setVisibility(View.GONE);
                regiMoreForm.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_regi:
                final FirebaseUser user = mAuth.getCurrentUser();

                if (et_name.getText().toString().length() <=0){
                    TastyToast.makeText(this, "Please enter your name", TastyToast.LENGTH_SHORT, TastyToast.ERROR).show();
                }
                else if (et_location.getText().toString().length()<=0){
                    TastyToast.makeText(this, "Enter a city you want to visit", TastyToast.LENGTH_SHORT, TastyToast.ERROR).show();
                }
                else if (et_visit.getText().toString().length()<=0){
                    TastyToast.makeText(this, "Please enter your location", TastyToast.LENGTH_SHORT, TastyToast.ERROR).show();
                }
                else
                {
                    int selectedGender=rg_gender.getCheckedRadioButtonId();
                    rb_gender=findViewById(selectedGender);

                    String str_name=et_name.getText().toString();
                    String str_dob=TV_dob.getText().toString();
                    String str_location= et_location.getText().toString();
                    String str_nationality= suggestion_nationality.getText().toString();
                    String str_lang=suggestion_lang.getText().toString();
                    str_lang = str_lang.replaceAll(", $", "");
                    String str_height= suggestion_height.getText().toString();
                    String str_body_type=Sp_bodytype.getSelectedItem().toString();
                    String str_eyes=Sp_eyes.getSelectedItem().toString();
                    String str_hair=Sp_hairs.getSelectedItem().toString();
                    String str_visit=et_visit.getText().toString();
                    String str_gender=rb_gender.getText().toString();

//                    String checkDOB=validateDOB(str_dob);
//                    if(checkDOB.equalsIgnoreCase("valid"))
//                    {
                    register(user,str_name,str_dob,str_gender,str_location,str_nationality,str_lang,str_look,str_height,str_body_type,str_eyes,str_hair,str_visit);
//                    }
//                    else
//                        {
//                        Toast.makeText(this, "Enter valid DOB", Toast.LENGTH_SHORT).show();
//                    }
                    Log.i("Simu"," "+str_height);
                }
//                startActivity(new Intent(this,TripsActivity.class));
                break;
        }
    }
}
