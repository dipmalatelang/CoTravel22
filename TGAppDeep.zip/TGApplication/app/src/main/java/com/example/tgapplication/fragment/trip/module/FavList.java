package com.example.tgapplication.fragment.trip.module;

public class FavList {
    public String id;

    public FavList(){

    }

    public FavList(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
