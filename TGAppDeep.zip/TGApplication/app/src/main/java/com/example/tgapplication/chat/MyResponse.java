package com.example.tgapplication.chat;

public class MyResponse {

    public int success;
}
